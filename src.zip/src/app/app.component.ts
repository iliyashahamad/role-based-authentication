import { Component, DoCheck } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck 
{
  title = 'role-based-auth';
  isMenuRequired=false;
  isAdmin=false;
  constructor(private service:AuthService,private router:Router){}
  ngDoCheck(): void 
  {
      let currentRoute=this.router.url;
      if(currentRoute=='/login' || currentRoute=='/register')
          this.isMenuRequired=false;
      else
          this.isMenuRequired=true;  
      if(sessionStorage.getItem("userrole")=="admin")
          this.isAdmin=true;
      else
        this.isAdmin=false; 
  }
}
