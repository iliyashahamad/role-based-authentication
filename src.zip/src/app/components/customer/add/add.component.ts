import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Customer } from 'src/app/customer';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit{

  constructor(private service:CustomerService,private toastr:ToastrService,private dialog:MatDialogRef<AddComponent>){}
  customer=new Customer();
  customerForm:FormGroup;
  ngOnInit(): void {  
     this.customerForm=new FormGroup({
       "id":new FormControl('',Validators.required),
       "firstname":new FormControl('',Validators.required),
       "lastname":new FormControl('',Validators.required),
       "address":new FormControl('',Validators.required),
       "phone":new FormControl('',Validators.required),
    });
 }
  addCustomer(){
    this.customer.id=this.customerForm.controls["id"].value;
    this.customer.firstname=this.customerForm.controls["firstname"].value;
    this.customer.lastname=this.customerForm.controls["lastname"].value;
    this.customer.address=this.customerForm.controls["address"].value;
    this.customer.phone=this.customerForm.controls["phone"].value;
    this.service.saveCustomer(this.customer).subscribe(res=>{
      this.toastr.success("Customer has been added successfully");
      this.dialog.close();
    });
  }
}
