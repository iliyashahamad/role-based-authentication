import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Customer } from 'src/app/customer';
import { CustomerService } from 'src/app/services/customer.service';
import { AddComponent } from '../add/add.component';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DeleteComponent } from '../delete/delete.component';
import { EditComponent } from '../edit/edit.component';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit{

  constructor(private customerService:CustomerService,private dialog:MatDialog){}
  @ViewChild(MatPaginator) paginator!:MatPaginator
  @ViewChild(MatSort) sort!:MatSort
  customerList:Customer[];
  dataSource:any;
  empty=false;
  isAdmin=true;
  displayedColumns:string[]=["id","firstname","lastname","address","phone","action"];
  ngOnInit(): void {
    this.loadCustomer();
    this.isAdmin=sessionStorage.getItem("userrole")=="admin";
  }
  loadCustomer(){
    this.customerService.getAllCustomers().subscribe({
      next:data=>{
        this.empty=false;
        this.customerList=data;
        this.dataSource=new MatTableDataSource(this.customerList);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      },
    });
  }
  addCustomer(){
      const popup=this.dialog.open(AddComponent,{
      enterAnimationDuration:'1000ms',
      exitAnimationDuration:'500ms',
      width:'40%'
    });
    popup.afterClosed().subscribe(res=>{
      this.loadCustomer();
    });
  }
  deleteCustomer(cid:any){
    const popup=this.dialog.open(DeleteComponent,{
      enterAnimationDuration:'1000ms',
      exitAnimationDuration:'500ms',
      width:'30%',
      data:{
        cid:cid
      }
    });
    popup.afterClosed().subscribe(res=>{
      this.loadCustomer();
    });
  }
  editCustomer(cid:any){
    const popup=this.dialog.open(EditComponent,{
      enterAnimationDuration:'1000ms',
      exitAnimationDuration:'500ms',
      width:'50%',
      data:{
        cid:cid
      }
    });
    popup.afterClosed().subscribe(res=>{
      this.loadCustomer();
    });
  }
}
