import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private service:AuthService,private router:Router,private toastr:ToastrService){
      sessionStorage.clear();
  }
  loginForm=new FormGroup({
    username:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required)
  });
  user:any;
  userLogin(){
    console.log(1)
    this.service.getUserByUsername(this.loginForm.value.username).subscribe({
      next:data=>{
        this.user=data;
        if(this.loginForm.value.password==this.user.password){
          if(this.user.isActive){
            sessionStorage.setItem("username",this.user.id);
            sessionStorage.setItem("userrole",this.user.role);
            this.router.navigate(['']);
          }else{
            this.toastr.error("Please contact to your adminstrator","You are not active user");
          }
          
        }else{
          this.toastr.error("Password is wrong");  
        }
      },error:err=>{
        this.toastr.error("User name does not exist");
      }
    })
  }
}
