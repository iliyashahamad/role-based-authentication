import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private client:HttpClient,private router:Router) { }
  baseUrl="http://localhost:3000/user";
  registerUser(user:any){
    return this.client.post(this.baseUrl,user);
  }
  getUserByUsername(username:any){
    return this.client.get(this.baseUrl+'/'+username);
  }
  getAllUsers(){
    return this.client.get(this.baseUrl);
  }
  getAllRoles(){
    return this.client.get("http://localhost:3000/role");
  }
  updateUser(username:any,user:any){
    return this.client.put(this.baseUrl+'/'+username,user);
  }
  isLoggedIn(){
    return sessionStorage.getItem("username")!=null;
  }
}
